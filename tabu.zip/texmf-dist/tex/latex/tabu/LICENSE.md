
LPPL licence

https://www.latex-project.org/lppl/lppl-1-3c/