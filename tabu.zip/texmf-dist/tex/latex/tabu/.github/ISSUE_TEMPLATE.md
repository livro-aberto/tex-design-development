> Please note that this package is unmaintained (see toplevel README)!!!
>
> So please be aware that getting a solution to a problem in a timely
> manner by reporting it is not likely to happen.
>
> Nevertheless, reporting issues is helpful, as we hope that a new
> maintainer will eventually take over the package support.

